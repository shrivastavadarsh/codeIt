/// API CALL
// define access parameters


async function apicall(){
  var accessToken = 'f3998ceb512f85d90816e4b6e32b025a';
  var endpoint = '20a10362.compilers.sphere-engine.com';
          
  const response = await fetch(
      'https://' + endpoint + '/api/v4/submissions?access_token=' + accessToken,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          access_token: accessToken,
          compilerId: 41,
          source: '#include <iostream>\n using namespace std;\n int main(){cout<<"Hello World!"<<endl;\n return 0;}'
        }),
      }
    );

   const jsonResponse = await response.json();
   console.log(jsonResponse);

    //console.log("Manas Bhosdiwala");

   return;
   //return jsonResponse
}
