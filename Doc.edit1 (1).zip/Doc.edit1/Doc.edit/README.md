# Collaborative-Editor
Collaborative doc editor with chat functionality using SOCKET.io and EXPRESS 
